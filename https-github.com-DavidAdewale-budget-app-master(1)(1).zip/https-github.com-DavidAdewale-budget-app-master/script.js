const footerDate = document.getElementById('year');

const currentYear = new Date().getFullYear();

footerDate.innerText = currentYear;
